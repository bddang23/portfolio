/* The Library Management System - Milestone1
 * A library has a set of users, a list of books and maintains a list of 
 * transactions to keep track of borrowed books
 *
 * @author  Binh Dang
 * @version 1.0
 * @since   2022-03-23
 */