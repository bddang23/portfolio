﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmChildren
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.txtBin1 = New System.Windows.Forms.TextBox()
        Me.txtDec1 = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.txtHex1 = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.txtHex2 = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.txtDec2 = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.txtBin2 = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.txtHexRes = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.txtDecRes = New System.Windows.Forms.TextBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.txtBinRes = New System.Windows.Forms.TextBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.btnA = New System.Windows.Forms.Button()
        Me.btnB = New System.Windows.Forms.Button()
        Me.btnC = New System.Windows.Forms.Button()
        Me.btnD = New System.Windows.Forms.Button()
        Me.btn9 = New System.Windows.Forms.Button()
        Me.btn8 = New System.Windows.Forms.Button()
        Me.btn7 = New System.Windows.Forms.Button()
        Me.btn6 = New System.Windows.Forms.Button()
        Me.btn5 = New System.Windows.Forms.Button()
        Me.btn4 = New System.Windows.Forms.Button()
        Me.btn3 = New System.Windows.Forms.Button()
        Me.btn2 = New System.Windows.Forms.Button()
        Me.btnF = New System.Windows.Forms.Button()
        Me.btnE = New System.Windows.Forms.Button()
        Me.btn1 = New System.Windows.Forms.Button()
        Me.btn0 = New System.Windows.Forms.Button()
        Me.btnConvert = New System.Windows.Forms.Button()
        Me.btnClear1 = New System.Windows.Forms.Button()
        Me.btnClear2 = New System.Windows.Forms.Button()
        Me.btnClearRes = New System.Windows.Forms.Button()
        Me.btnAnd = New System.Windows.Forms.Button()
        Me.btnOr = New System.Windows.Forms.Button()
        Me.btnXor = New System.Windows.Forms.Button()
        Me.btnNot1 = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(34, 9)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(52, 17)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Binary "
        '
        'txtBin1
        '
        Me.txtBin1.Location = New System.Drawing.Point(37, 29)
        Me.txtBin1.Name = "txtBin1"
        Me.txtBin1.Size = New System.Drawing.Size(306, 22)
        Me.txtBin1.TabIndex = 1
        Me.txtBin1.Text = "0"
        '
        'txtDec1
        '
        Me.txtDec1.Location = New System.Drawing.Point(37, 84)
        Me.txtDec1.Name = "txtDec1"
        Me.txtDec1.Size = New System.Drawing.Size(306, 22)
        Me.txtDec1.TabIndex = 3
        Me.txtDec1.Text = "0"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(34, 64)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(62, 17)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "Decimal "
        '
        'txtHex1
        '
        Me.txtHex1.Location = New System.Drawing.Point(37, 142)
        Me.txtHex1.Name = "txtHex1"
        Me.txtHex1.Size = New System.Drawing.Size(306, 22)
        Me.txtHex1.TabIndex = 5
        Me.txtHex1.Text = "0"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(34, 122)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(32, 17)
        Me.Label3.TabIndex = 4
        Me.Label3.Text = "Hex"
        '
        'txtHex2
        '
        Me.txtHex2.Location = New System.Drawing.Point(390, 142)
        Me.txtHex2.Name = "txtHex2"
        Me.txtHex2.Size = New System.Drawing.Size(309, 22)
        Me.txtHex2.TabIndex = 11
        Me.txtHex2.Text = "0"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(387, 122)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(32, 17)
        Me.Label4.TabIndex = 10
        Me.Label4.Text = "Hex"
        '
        'txtDec2
        '
        Me.txtDec2.Location = New System.Drawing.Point(390, 84)
        Me.txtDec2.Name = "txtDec2"
        Me.txtDec2.Size = New System.Drawing.Size(309, 22)
        Me.txtDec2.TabIndex = 9
        Me.txtDec2.Text = "0"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(387, 64)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(62, 17)
        Me.Label5.TabIndex = 8
        Me.Label5.Text = "Decimal "
        '
        'txtBin2
        '
        Me.txtBin2.Location = New System.Drawing.Point(390, 29)
        Me.txtBin2.Name = "txtBin2"
        Me.txtBin2.Size = New System.Drawing.Size(309, 22)
        Me.txtBin2.TabIndex = 7
        Me.txtBin2.Text = "0"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(387, 9)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(52, 17)
        Me.Label6.TabIndex = 6
        Me.Label6.Text = "Binary "
        '
        'txtHexRes
        '
        Me.txtHexRes.Location = New System.Drawing.Point(726, 142)
        Me.txtHexRes.Name = "txtHexRes"
        Me.txtHexRes.ReadOnly = True
        Me.txtHexRes.Size = New System.Drawing.Size(292, 22)
        Me.txtHexRes.TabIndex = 17
        Me.txtHexRes.Text = "0"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(723, 122)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(32, 17)
        Me.Label7.TabIndex = 16
        Me.Label7.Text = "Hex"
        '
        'txtDecRes
        '
        Me.txtDecRes.Location = New System.Drawing.Point(726, 84)
        Me.txtDecRes.Name = "txtDecRes"
        Me.txtDecRes.ReadOnly = True
        Me.txtDecRes.Size = New System.Drawing.Size(292, 22)
        Me.txtDecRes.TabIndex = 15
        Me.txtDecRes.Text = "0"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(723, 64)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(62, 17)
        Me.Label8.TabIndex = 14
        Me.Label8.Text = "Decimal "
        '
        'txtBinRes
        '
        Me.txtBinRes.Location = New System.Drawing.Point(726, 29)
        Me.txtBinRes.Name = "txtBinRes"
        Me.txtBinRes.ReadOnly = True
        Me.txtBinRes.Size = New System.Drawing.Size(292, 22)
        Me.txtBinRes.TabIndex = 13
        Me.txtBinRes.Text = "0"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(723, 9)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(52, 17)
        Me.Label9.TabIndex = 12
        Me.Label9.Text = "Binary "
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(120, 183)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(60, 17)
        Me.Label10.TabIndex = 18
        Me.Label10.Text = "Value 1 "
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(473, 183)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(56, 17)
        Me.Label11.TabIndex = 19
        Me.Label11.Text = "Value 2"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(831, 183)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(48, 17)
        Me.Label12.TabIndex = 20
        Me.Label12.Text = "Result"
        '
        'btnA
        '
        Me.btnA.Location = New System.Drawing.Point(76, 253)
        Me.btnA.Name = "btnA"
        Me.btnA.Size = New System.Drawing.Size(43, 33)
        Me.btnA.TabIndex = 21
        Me.btnA.Text = "A"
        Me.btnA.UseVisualStyleBackColor = True
        '
        'btnB
        '
        Me.btnB.Location = New System.Drawing.Point(137, 253)
        Me.btnB.Name = "btnB"
        Me.btnB.Size = New System.Drawing.Size(43, 33)
        Me.btnB.TabIndex = 22
        Me.btnB.Text = "B"
        Me.btnB.UseVisualStyleBackColor = True
        '
        'btnC
        '
        Me.btnC.Location = New System.Drawing.Point(201, 253)
        Me.btnC.Name = "btnC"
        Me.btnC.Size = New System.Drawing.Size(43, 33)
        Me.btnC.TabIndex = 23
        Me.btnC.Text = "C"
        Me.btnC.UseVisualStyleBackColor = True
        '
        'btnD
        '
        Me.btnD.Location = New System.Drawing.Point(266, 253)
        Me.btnD.Name = "btnD"
        Me.btnD.Size = New System.Drawing.Size(43, 33)
        Me.btnD.TabIndex = 24
        Me.btnD.Text = "D"
        Me.btnD.UseVisualStyleBackColor = True
        '
        'btn9
        '
        Me.btn9.Location = New System.Drawing.Point(266, 292)
        Me.btn9.Name = "btn9"
        Me.btn9.Size = New System.Drawing.Size(43, 33)
        Me.btn9.TabIndex = 28
        Me.btn9.Text = "9"
        Me.btn9.UseVisualStyleBackColor = True
        '
        'btn8
        '
        Me.btn8.Location = New System.Drawing.Point(201, 292)
        Me.btn8.Name = "btn8"
        Me.btn8.Size = New System.Drawing.Size(43, 33)
        Me.btn8.TabIndex = 27
        Me.btn8.Text = "8"
        Me.btn8.UseVisualStyleBackColor = True
        '
        'btn7
        '
        Me.btn7.Location = New System.Drawing.Point(137, 292)
        Me.btn7.Name = "btn7"
        Me.btn7.Size = New System.Drawing.Size(43, 33)
        Me.btn7.TabIndex = 26
        Me.btn7.Text = "7"
        Me.btn7.UseVisualStyleBackColor = True
        '
        'btn6
        '
        Me.btn6.Location = New System.Drawing.Point(76, 292)
        Me.btn6.Name = "btn6"
        Me.btn6.Size = New System.Drawing.Size(43, 33)
        Me.btn6.TabIndex = 25
        Me.btn6.Text = "6"
        Me.btn6.UseVisualStyleBackColor = True
        '
        'btn5
        '
        Me.btn5.Location = New System.Drawing.Point(266, 331)
        Me.btn5.Name = "btn5"
        Me.btn5.Size = New System.Drawing.Size(43, 33)
        Me.btn5.TabIndex = 32
        Me.btn5.Text = "5"
        Me.btn5.UseVisualStyleBackColor = True
        '
        'btn4
        '
        Me.btn4.Location = New System.Drawing.Point(201, 331)
        Me.btn4.Name = "btn4"
        Me.btn4.Size = New System.Drawing.Size(43, 33)
        Me.btn4.TabIndex = 31
        Me.btn4.Text = "4"
        Me.btn4.UseVisualStyleBackColor = True
        '
        'btn3
        '
        Me.btn3.Location = New System.Drawing.Point(137, 331)
        Me.btn3.Name = "btn3"
        Me.btn3.Size = New System.Drawing.Size(43, 33)
        Me.btn3.TabIndex = 30
        Me.btn3.Text = "3"
        Me.btn3.UseVisualStyleBackColor = True
        '
        'btn2
        '
        Me.btn2.Location = New System.Drawing.Point(76, 331)
        Me.btn2.Name = "btn2"
        Me.btn2.Size = New System.Drawing.Size(43, 33)
        Me.btn2.TabIndex = 29
        Me.btn2.Text = "2"
        Me.btn2.UseVisualStyleBackColor = True
        '
        'btnF
        '
        Me.btnF.Location = New System.Drawing.Point(390, 253)
        Me.btnF.Name = "btnF"
        Me.btnF.Size = New System.Drawing.Size(43, 33)
        Me.btnF.TabIndex = 36
        Me.btnF.Text = "F"
        Me.btnF.UseVisualStyleBackColor = True
        '
        'btnE
        '
        Me.btnE.Location = New System.Drawing.Point(325, 253)
        Me.btnE.Name = "btnE"
        Me.btnE.Size = New System.Drawing.Size(43, 33)
        Me.btnE.TabIndex = 35
        Me.btnE.Text = "E"
        Me.btnE.UseVisualStyleBackColor = True
        '
        'btn1
        '
        Me.btn1.Location = New System.Drawing.Point(137, 370)
        Me.btn1.Name = "btn1"
        Me.btn1.Size = New System.Drawing.Size(43, 33)
        Me.btn1.TabIndex = 34
        Me.btn1.Text = "1"
        Me.btn1.UseVisualStyleBackColor = True
        '
        'btn0
        '
        Me.btn0.Location = New System.Drawing.Point(76, 370)
        Me.btn0.Name = "btn0"
        Me.btn0.Size = New System.Drawing.Size(43, 33)
        Me.btn0.TabIndex = 33
        Me.btn0.Text = "0"
        Me.btn0.UseVisualStyleBackColor = True
        '
        'btnConvert
        '
        Me.btnConvert.Location = New System.Drawing.Point(322, 292)
        Me.btnConvert.Name = "btnConvert"
        Me.btnConvert.Size = New System.Drawing.Size(110, 110)
        Me.btnConvert.TabIndex = 37
        Me.btnConvert.Text = "Convert"
        Me.btnConvert.UseVisualStyleBackColor = True
        '
        'btnClear1
        '
        Me.btnClear1.Location = New System.Drawing.Point(542, 253)
        Me.btnClear1.Name = "btnClear1"
        Me.btnClear1.Size = New System.Drawing.Size(184, 33)
        Me.btnClear1.TabIndex = 38
        Me.btnClear1.Text = "Clear Value 1"
        Me.btnClear1.UseVisualStyleBackColor = True
        '
        'btnClear2
        '
        Me.btnClear2.Location = New System.Drawing.Point(542, 292)
        Me.btnClear2.Name = "btnClear2"
        Me.btnClear2.Size = New System.Drawing.Size(184, 33)
        Me.btnClear2.TabIndex = 39
        Me.btnClear2.Text = "Clear Value 2"
        Me.btnClear2.UseVisualStyleBackColor = True
        '
        'btnClearRes
        '
        Me.btnClearRes.Location = New System.Drawing.Point(542, 331)
        Me.btnClearRes.Name = "btnClearRes"
        Me.btnClearRes.Size = New System.Drawing.Size(184, 33)
        Me.btnClearRes.TabIndex = 40
        Me.btnClearRes.Text = "Clear Result"
        Me.btnClearRes.UseVisualStyleBackColor = True
        '
        'btnAnd
        '
        Me.btnAnd.Location = New System.Drawing.Point(834, 253)
        Me.btnAnd.Name = "btnAnd"
        Me.btnAnd.Size = New System.Drawing.Size(114, 33)
        Me.btnAnd.TabIndex = 41
        Me.btnAnd.Text = "And"
        Me.btnAnd.UseVisualStyleBackColor = True
        '
        'btnOr
        '
        Me.btnOr.Location = New System.Drawing.Point(834, 292)
        Me.btnOr.Name = "btnOr"
        Me.btnOr.Size = New System.Drawing.Size(114, 33)
        Me.btnOr.TabIndex = 42
        Me.btnOr.Text = "Or"
        Me.btnOr.UseVisualStyleBackColor = True
        '
        'btnXor
        '
        Me.btnXor.Location = New System.Drawing.Point(834, 331)
        Me.btnXor.Name = "btnXor"
        Me.btnXor.Size = New System.Drawing.Size(114, 33)
        Me.btnXor.TabIndex = 43
        Me.btnXor.Text = "Xor"
        Me.btnXor.UseVisualStyleBackColor = True
        '
        'btnNot1
        '
        Me.btnNot1.Location = New System.Drawing.Point(834, 370)
        Me.btnNot1.Name = "btnNot1"
        Me.btnNot1.Size = New System.Drawing.Size(114, 33)
        Me.btnNot1.TabIndex = 44
        Me.btnNot1.Text = "Not Value 1"
        Me.btnNot1.UseVisualStyleBackColor = True
        '
        'frmChildren
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1030, 450)
        Me.Controls.Add(Me.btnNot1)
        Me.Controls.Add(Me.btnXor)
        Me.Controls.Add(Me.btnOr)
        Me.Controls.Add(Me.btnAnd)
        Me.Controls.Add(Me.btnClearRes)
        Me.Controls.Add(Me.btnClear2)
        Me.Controls.Add(Me.btnClear1)
        Me.Controls.Add(Me.btnConvert)
        Me.Controls.Add(Me.btnF)
        Me.Controls.Add(Me.btnE)
        Me.Controls.Add(Me.btn1)
        Me.Controls.Add(Me.btn0)
        Me.Controls.Add(Me.btn5)
        Me.Controls.Add(Me.btn4)
        Me.Controls.Add(Me.btn3)
        Me.Controls.Add(Me.btn2)
        Me.Controls.Add(Me.btn9)
        Me.Controls.Add(Me.btn8)
        Me.Controls.Add(Me.btn7)
        Me.Controls.Add(Me.btn6)
        Me.Controls.Add(Me.btnD)
        Me.Controls.Add(Me.btnC)
        Me.Controls.Add(Me.btnB)
        Me.Controls.Add(Me.btnA)
        Me.Controls.Add(Me.Label12)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.txtHexRes)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.txtDecRes)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.txtBinRes)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.txtHex2)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.txtDec2)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.txtBin2)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.txtHex1)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.txtDec1)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.txtBin1)
        Me.Controls.Add(Me.Label1)
        Me.Name = "frmChildren"
        Me.Text = "Calc"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents txtBin1 As TextBox
    Friend WithEvents txtDec1 As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents txtHex1 As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents txtHex2 As TextBox
    Friend WithEvents Label4 As Label
    Friend WithEvents txtDec2 As TextBox
    Friend WithEvents Label5 As Label
    Friend WithEvents txtBin2 As TextBox
    Friend WithEvents Label6 As Label
    Friend WithEvents txtHexRes As TextBox
    Friend WithEvents Label7 As Label
    Friend WithEvents txtDecRes As TextBox
    Friend WithEvents Label8 As Label
    Friend WithEvents txtBinRes As TextBox
    Friend WithEvents Label9 As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents Label11 As Label
    Friend WithEvents Label12 As Label
    Friend WithEvents btnA As Button
    Friend WithEvents btnB As Button
    Friend WithEvents btnC As Button
    Friend WithEvents btnD As Button
    Friend WithEvents btn9 As Button
    Friend WithEvents btn8 As Button
    Friend WithEvents btn7 As Button
    Friend WithEvents btn6 As Button
    Friend WithEvents btn5 As Button
    Friend WithEvents btn4 As Button
    Friend WithEvents btn3 As Button
    Friend WithEvents btn2 As Button
    Friend WithEvents btnF As Button
    Friend WithEvents btnE As Button
    Friend WithEvents btn1 As Button
    Friend WithEvents btn0 As Button
    Friend WithEvents btnConvert As Button
    Friend WithEvents btnClear1 As Button
    Friend WithEvents btnClear2 As Button
    Friend WithEvents btnClearRes As Button
    Friend WithEvents btnAnd As Button
    Friend WithEvents btnOr As Button
    Friend WithEvents btnXor As Button
    Friend WithEvents btnNot1 As Button
End Class
